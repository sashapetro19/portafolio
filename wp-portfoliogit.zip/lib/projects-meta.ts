export type ProjectMeta = {
  slug: string
  categories: string[]
  tools: string[]
  hero: string
  gallery: string[]
  external?: string
  stats?: { label: string; value: string }[]
  content: {
    intro: string
    challenge: string
    solution: string
    results: string
  }
}

// Datos neutrales (no dependen del idioma de títulos/descripciones)
export const projectsMeta: ProjectMeta[] = [
  {
    slug: "landing-redesign",
    categories: ["UX", "UI", "Web"],
    tools: ["Figma", "Webflow", "JS"],
    hero: "/project-landing-screenshot.png",
    gallery: ["/project-landing-screenshot.png", "/photos/IMG_1621.jpg"],
    external: "https://example.com/landing",
    stats: [
      { label: "Conversión", value: "+28%" },
      { label: "CWV", value: "90+ score" },
    ],
    content: {
      intro: "Rediseño orientado a conversión con investigación ligera y prototipado rápido.",
      challenge: "Baja conversión y jerarquía confusa en la landing original.",
      solution:
        "Mapa de calor + wireframes → prototipo en Figma → validación con 5 usuarios → implementación en Webflow con animaciones sutiles.",
      results: "Aumento de conversiones y mejor claridad de propuesta de valor.",
    },
  },
  {
    slug: "ecommerce-ui-kit",
    categories: ["Design System", "UI"],
    tools: ["Figma", "Tokens", "Auto‑layout"],
    hero: "/ecommerce-ui-components.png",
    gallery: ["/ecommerce-ui-components.png", "/photos/20241016_160233.jpg"],
    external: "https://example.com/ui-kit",
    stats: [
      { label: "Tiempo a prototipo", value: "-40%" },
      { label: "Consistencia", value: "+100%" },
    ],
    content: {
      intro: "UI Kit modular para e‑commerce con tokens y variantes responsivas.",
      challenge: "Inconsistencias visuales y tiempos largos de diseño.",
      solution:
        "Definición de tokens, tipografía, espaciado y componentes clave con estados y accesibilidad.",
      results: "Aceleró el time‑to‑market y redujo deuda de diseño.",
    },
  },
  {
    slug: "minimal-portfolio",
    categories: ["Frontend", "UX", "Performance"],
    tools: ["Next.js", "Tailwind", "a11y"],
    hero: "/minimal-portfolio-mockup.png",
    gallery: ["/minimal-portfolio-mockup.png", "/photos/IMG-20231015-WA0021-1.jpg"],
    external: "https://example.com/portfolio",
    stats: [
      { label: "LCP", value: "< 1.8s" },
      { label: "Páginas", value: "5" },
    ],
    content: {
      intro: "Portfolio minimal con foco en accesibilidad y velocidad.",
      challenge: "Mostrar trabajo con claridad en dispositivos móviles.",
      solution:
        "Arquitectura ligera, tipografía legible, navegación simple y componentes accesibles.",
      results: "Mejor experiencia móvil y SEO técnico base.",
    },
  },
]
