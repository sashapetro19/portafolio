export type Course = {
  name: string
  dates: string
}

export type TimelineItem = {
  title: string
  org: string
  location?: string
  start: string
  end: string
  bullets: string[]
}

export type EducationItem = {
  degree: string
  org: string
  location?: string
  year: string
  bullets: string[]
}

export type CV = {
  name: string
  surname: string
  role: string
  contacts: {
    addresses: string[]
    email: string
    phone: string
    linkedin?: string
  }
  about: string
  courses: Course[]
  languages: string[]
  drivingLicense?: string
  skills: string[]
  experience: TimelineItem[]
  internship: TimelineItem[]
  education: EducationItem[]
  // Portfolio de ejemplo (puedes remplazar/ocultar más tarde)
  projects: {
    id: string
    title: string
    description: string
    image: string
    url?: string
  }[]
}

export const cv: CV = {
  name: "Oleksandr",
  surname: "Petryshchenko",
  role: "UX / UI Designer",
  contacts: {
    addresses: [
      "Valencia, 46007, España",
      "Valencia, 46023, España",
    ],
    email: "sashapetri11@gmail.com",
    phone: "+34 643 109 927",
    linkedin: "https://www.linkedin.com/in/opetryshchenko",
  },
  about:
    "Como artesano de experiencias digitales, creo interfaces visualmente atractivas e intuitivamente funcionales. Mi enfoque se basa en el diseño centrado en el usuario, asegurando accesibilidad y engagement. Domino Figma, Adobe XD y Webflow, y no temo al código. Busco soluciones elegantes que unan emoción e interacción para ofrecer experiencias excepcionales.",
  courses: [
    {
      name: "Foundations of User Experience (UX)",
      dates: "Jun 2024 – Dec 2024",
    },
    {
      name: "Start the UX Design Process: Empathize, Define, and Ideate",
      dates: "Mar 2024 – Dec 2024",
    },
  ],
  languages: ["Ukrainian", "Russian", "Spanish", "English"],
  drivingLicense: "B",
  skills: [
    "Desarrollo, diseño y testeo de sitios y software",
    "Soporte técnico",
    "Administración de sistemas",
    "Figma",
    "Adobe XD",
    "Webflow",
    "JavaScript",
    "Python",
    "Java",
    "C++",
    "React",
    "WordPress",
    "Bases de datos",
    "Algoritmos",
    "OS & Networking",
    "Metodologías Ágiles",
  ],
  experience: [
    {
      title: "Programmer & UI/UX Designer",
      org: "Monopole Cerámica S.L",
      location: "Valencia",
      start: "Feb 2025",
      end: "May 2025",
      bullets: [
        "Diseño de interfaces siguiendo tendencias y buenas prácticas UI/UX.",
        "Creación de wireframes, storyboards, user flows y process flows.",
        "Tests con usuarios y focus groups para iterar en mejoras.",
        "Optimización de velocidad, escalabilidad y seguridad.",
        "Uso de JavaScript, Python o Java para soluciones de software.",
      ],
    },
    {
      title: "Technical Support Technician",
      org: "Laberit S.L",
      location: "Valencia",
      start: "May 2022",
      end: "Aug 2024",
      bullets: [
        "Administración de AD, VPNs y Microsoft 365 garantizando continuidad.",
        "Instalación y configuración de apps y software.",
        "Soporte técnico en Instituto Valenciano de Oncología (IVO).",
        "Resolución de incidencias y mejora de satisfacción del cliente.",
      ],
    },
    {
      title: "Electronics Engineer & Teacher",
      org: "Laberit S.L",
      location: "—",
      start: "Sep 2020",
      end: "May 2022",
      bullets: [
        "Mantenimiento y modernización de equipos. Formación de empleados.",
        "Simplificación de procesos y optimización de red.",
        "Instalación de equipos y soluciones de Internet.",
        "Desarrollo, diseño y testeo de sitios y software.",
        "Docencia en informática y programación.",
      ],
    },
  ],
  internship: [
    {
      title: "Web Developer (Internship)",
      org: "Zhmiivksa School",
      location: "Zhmiivka",
      start: "Nov 2019",
      end: "May 2020",
      bullets: [
        "Creación y testeo de plataforma social para estudiantes.",
      ],
    },
  ],
  education: [
    {
      degree: "Bachelor",
      org: "Vernadsky Tavriya National University",
      location: "Kyiv",
      year: "2023",
      bullets: [
        "Desarrollo y optimización de software",
        "Depuración avanzada (debugging)",
        "Metodologías Ágiles",
        "Conocimiento full‑stack",
        "Algoritmos",
        "C++, Java y Python",
        "Arquitectura de computadores",
        "Sistemas Operativos y Redes",
        "Gestión de bases de datos",
        "Competencia en UX/UI",
      ],
    },
    {
      degree: "Some college (no degree)",
      org: "Rzhyshchiv Industrial And Pedagogical Vocational College",
      location: "Rzishchiv",
      year: "2020",
      bullets: [
        "Ingeniería de software",
        "Especialización en UX/UI",
        "Programación técnica",
        "Creación de vídeo",
      ],
    },
  ],
  projects: [
    // Puedes sustituir más tarde con proyectos reales
    {
      id: "p1",
      title: "Rediseño de landing",
      description: "Optimización de conversión con enfoque UX.",
      image: "/project-landing-screenshot.png",
      url: "https://example.com/landing",
    },
    {
      id: "p2",
      title: "UI Kit E‑commerce",
      description: "Biblioteca de componentes para tienda.",
      image: "/ecommerce-ui-components.png",
      url: "https://example.com/ui-kit",
    },
    {
      id: "p3",
      title: "Portfolio minimal",
      description: "Accesibilidad y performance.",
      image: "/minimal-portfolio-mockup.png",
      url: "https://example.com/portfolio",
    },
  ],
}
