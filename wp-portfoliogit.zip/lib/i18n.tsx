"use client"

import { createContext, useContext, useEffect, useMemo, useState } from "react"

export type Locale = "es" | "en" | "uk" | "ru"

export type Course = { name: string; dates: string }
export type TimelineItem = {
  title: string
  org: string
  location?: string
  start: string
  end: string
  bullets: string[]
}
export type EducationItem = {
  degree: string
  org: string
  location?: string
  year: string
  bullets: string[]
}
export type ProjectListItem = {
  id: string
  slug: string
  title: string
  description: string
  image: string
  url?: string
}

export type CV = {
  name: string
  surname: string
  role: string
  contacts: {
    addresses: string[]
    email: string
    phone: string
    linkedin?: string
  }
  about: string
  courses: Course[]
  languages: string[]
  drivingLicense?: string
  skills: string[]
  experience: TimelineItem[]
  internship: TimelineItem[]
  education: EducationItem[]
  projects: ProjectListItem[]
}

export type Dict = {
  nav: { home: string; about: string; portfolio: string; services: string; contact: string }
  hero: { available: string; email: string; call: string; linkedin: string }
  sections: {
    skills: string
    courses: string
    experience: string
    internship: string
    education: string
    portfolio: string
    contactMore: string
    tools: string
    categories: string
    caseStudy: string
  }
  cta: {
    viewAll: string
    learnMore: string
    writeMe: string
    details: string
    viewSite: string
    searchProjects: string
    notFound: string
    back: string
  }
  contact: { contact: string; languages: string; license: string; emailLabel: string; phoneLabel: string }
  services: { title: string; items: { title: string; desc: string }[] }
  cv: CV
}

const baseContacts = {
  addresses: ["Valencia, 46007, España", "Valencia, 46023, España"],
  email: "sashapetri11@gmail.com",
  phone: "+34 643 109 927",
  linkedin: "https://www.linkedin.com/in/opetryshchenko",
}

const baseList = [
  { id: "p1", slug: "landing-redesign", image: "/project-landing-screenshot.png", url: "https://example.com/landing" },
  { id: "p2", slug: "ecommerce-ui-kit", image: "/ecommerce-ui-components.png", url: "https://example.com/ui-kit" },
  { id: "p3", slug: "minimal-portfolio", image: "/minimal-portfolio-mockup.png", url: "https://example.com/portfolio" },
]

// ES
const es: Dict = {
  nav: { home: "Inicio", about: "Sobre mí", portfolio: "Portafolio", services: "Servicios", contact: "Contacto" },
  hero: { available: "Disponible para proyectos", email: "Email", call: "Llamar", linkedin: "LinkedIn" },
  sections: {
    skills: "Skills",
    courses: "Cursos",
    experience: "Experiencia",
    internship: "Prácticas",
    education: "Educación",
    portfolio: "Portafolio",
    contactMore: "Contacto & Más",
    tools: "Herramientas",
    categories: "Categorías",
    caseStudy: "Caso de estudio",
  },
  cta: {
    viewAll: "Ver todo",
    learnMore: "Saber más",
    writeMe: "Escríbeme",
    details: "Detalles",
    viewSite: "Ver sitio",
    searchProjects: "Buscar proyectos…",
    notFound: "No se encontraron proyectos.",
    back: "Volver",
  },
  contact: { contact: "Contacto", languages: "Idiomas", license: "Licencia de conducir", emailLabel: "Email", phoneLabel: "Teléfono" },
  services: {
    title: "Servicios",
    items: [
      { title: "Diseño UX/UI", desc: "Investigación, wireframes, prototipos y diseño visual centrado en el usuario." },
      { title: "Front‑end", desc: "Interfaces accesibles y rápidas (React/WordPress)." },
      { title: "Sistemas y Soporte", desc: "Administración básica, diagnóstico y optimización de entornos." },
      { title: "Optimización", desc: "Rendimiento, Core Web Vitals y escalabilidad." },
    ],
  },
  cv: {
    name: "Oleksandr",
    surname: "Petryshchenko",
    role: "UX / UI Designer",
    contacts: baseContacts,
    about:
      "Artesano de experiencias digitales: interfaces visuales e intuitivas, centradas en el usuario y accesibles. Figma, Adobe XD, Webflow y código cuando aporta valor.",
    courses: [
      { name: "Fundamentos de UX", dates: "Jun 2024 – Dic 2024" },
      { name: "Proceso UX: Empatizar, Definir e Idear", dates: "Mar 2024 – Dic 2024" },
    ],
    languages: ["Ucraniano", "Ruso", "Español", "Inglés"],
    drivingLicense: "B",
    skills: [
      "Desarrollo, diseño y testeo",
      "Soporte técnico",
      "Administración de sistemas",
      "Figma",
      "Adobe XD",
      "Webflow",
      "JavaScript",
      "Python",
      "Java",
      "C++",
      "React",
      "WordPress",
      "Bases de datos",
      "Algoritmos",
      "Sistemas y Redes",
      "Metodologías Ágiles",
    ],
    experience: [
      {
        title: "Programmer & UI/UX Designer",
        org: "Monopole Cerámica S.L",
        location: "Valencia",
        start: "Feb 2025",
        end: "May 2025",
        bullets: [
          "Interfaces según buenas prácticas UI/UX.",
          "Wireframes, storyboards, user flows y process flows.",
          "Tests con usuarios y focus groups.",
          "Optimización de velocidad, escalabilidad y seguridad.",
          "Uso de JavaScript, Python y Java.",
        ],
      },
      {
        title: "Technical Support Technician",
        org: "Laberit S.L",
        location: "Valencia",
        start: "May 2022",
        end: "Aug 2024",
        bullets: [
          "Administración de AD, VPNs y Microsoft 365.",
          "Instalación y configuración de software.",
          "Soporte en IVO.",
          "Resolución de incidencias y satisfacción del cliente.",
        ],
      },
      {
        title: "Electronics Engineer & Teacher",
        org: "Laberit S.L",
        location: "",
        start: "Sep 2020",
        end: "May 2022",
        bullets: [
          "Mantenimiento y modernización de equipos. Formación.",
          "Optimización de procesos y red.",
          "Instalación de equipos de Internet.",
          "Desarrollo y testeo de sitios y software.",
          "Docencia en informática y programación.",
        ],
      },
    ],
    internship: [
      {
        title: "Web Developer (Internship)",
        org: "Zhmiivksa School",
        location: "Zhmiivka",
        start: "Nov 2019",
        end: "May 2020",
        bullets: ["Plataforma social para estudiantes y testing."],
      },
    ],
    education: [
      {
        degree: "Bachelor",
        org: "Vernadsky Tavriya National University",
        location: "Kyiv",
        year: "2023",
        bullets: [
          "Desarrollo y optimización de software",
          "Debugging",
          "Metodologías Ágiles",
          "Full‑stack",
          "Algoritmos",
          "C++, Java, Python",
          "Arquitectura de computadores",
          "Sistemas Operativos y Redes",
          "Bases de datos",
          "UX/UI",
        ],
      },
      {
        degree: "Some college (sin título)",
        org: "Rzhyshchiv Industrial And Pedagogical Vocational College",
        location: "Rzishchiv",
        year: "2020",
        bullets: ["Ingeniería de software", "UX/UI", "Programación técnica", "Creación de vídeo"],
      },
    ],
    projects: baseList.map((b, i) => ({
      ...b,
      title: ["Rediseño de landing", "UI Kit E‑commerce", "Portfolio minimal"][i],
      description: ["Optimización de conversión.", "Componentes reutilizables.", "Accesible y rápido."][i],
    })),
  },
}

// EN
const en: Dict = {
  ...es,
  nav: { home: "Home", about: "About", portfolio: "Portfolio", services: "Services", contact: "Contact" },
  hero: { available: "Available for projects", email: "Email", call: "Call", linkedin: "LinkedIn" },
  sections: { ...es.sections, skills: "Key Skills", courses: "Courses", experience: "Work Experience", internship: "Internship", contactMore: "Contact & More", tools: "Tools", categories: "Categories", caseStudy: "Case study" },
  cta: { ...es.cta, viewAll: "View all", learnMore: "Learn more", writeMe: "Write me", details: "Details", viewSite: "View site", searchProjects: "Search projects…", notFound: "No projects found.", back: "Back" },
  contact: { ...es.contact, languages: "Languages", license: "Driving license", phoneLabel: "Phone" },
  cv: {
    ...es.cv,
    role: "UX / UI Designer",
    languages: ["Ukrainian", "Russian", "Spanish", "English"],
    projects: baseList.map((b, i) => ({
      ...b,
      title: ["Landing redesign", "E‑commerce UI Kit", "Minimal portfolio"][i],
      description: ["Conversion‑focused optimization.", "Reusable components.", "Accessible and fast."][i],
    })),
  },
}

// UK
const uk: Dict = {
  ...es,
  nav: { home: "Головна", about: "Про мене", portfolio: "Портфоліо", services: "Послуги", contact: "Контакти" },
  hero: { available: "Доступний для проєктів", email: "Email", call: "Зателефонувати", linkedin: "LinkedIn" },
  sections: { ...es.sections, skills: "Ключові навички", courses: "Курси", experience: "Досвід роботи", internship: "Стажування", education: "Освіта", portfolio: "Портфоліо", contactMore: "Контакти та інше", tools: "Інструменти", categories: "Категорії", caseStudy: "Кейс" },
  cta: { ...es.cta, viewAll: "Переглянути все", learnMore: "Дізнатись більше", writeMe: "Написати мені", details: "Деталі", viewSite: "Перейти", searchProjects: "Пошук проєктів…", notFound: "Проєктів не знайдено.", back: "Назад" },
  contact: { ...es.contact, languages: "Мови", license: "Посвідчення водія", phoneLabel: "Телефон" },
  cv: {
    ...es.cv,
    role: "UX / UI Дизайнер",
    languages: ["Українська", "Російська", "Іспанська", "Англійська"],
    projects: baseList.map((b, i) => ({
      ...b,
      title: ["Редизайн лендингу", "UI‑кіт для e‑commerce", "Мінімалістичне портфоліо"][i],
      description: ["Оптимізація конверсії.", "Повторно використовувані компоненти.", "Доступний та швидкий."][i],
    })),
  },
}

// RU
const ru: Dict = {
  ...es,
  nav: { home: "Главная", about: "Обо мне", portfolio: "Портфолио", services: "Услуги", contact: "Контакты" },
  hero: { available: "Доступен для проектов", email: "Email", call: "Позвонить", linkedin: "LinkedIn" },
  sections: { ...es.sections, skills: "Ключевые навыки", courses: "Курсы", experience: "Опыт работы", internship: "Стажировка", education: "Образование", portfolio: "Портфолио", contactMore: "Контакты и другое", tools: "Инструменты", categories: "Категории", caseStudy: "Кейс" },
  cta: { ...es.cta, viewAll: "Смотреть все", learnMore: "Узнать больше", writeMe: "Написать мне", details: "Подробнее", viewSite: "Открыть сайт", searchProjects: "Поиск проектов…", notFound: "Проекты не найдены.", back: "Назад" },
  contact: { ...es.contact, languages: "Языки", license: "Водительское удостоверение", phoneLabel: "Телефон" },
  cv: {
    ...es.cv,
    role: "UX / UI Дизайнер",
    languages: ["Украинский", "Русский", "Испанский", "Английский"],
    projects: baseList.map((b, i) => ({
      ...b,
      title: ["Редизайн лендинга", "UI Kit для e‑commerce", "Минималистичное портфолио"][i],
      description: ["Оптимизация конверсии.", "Переиспользуемые компоненты.", "Доступный и быстрый."][i],
    })),
  },
}

const dicts: Record<Locale, Dict> = { es, en, uk, ru }

type I18nContextValue = { locale: Locale; setLocale: (l: Locale) => void; t: Dict }

const I18nContext = createContext<I18nContextValue | null>(null)

function getLangFromURL(): Locale | null {
  if (typeof window === "undefined") return null
  const url = new URL(window.location.href)
  const lang = url.searchParams.get("lang") as Locale | null
  return lang && dicts[lang] ? lang : null
}

export function I18nProvider({ children }: { children?: React.ReactNode }) {
  const [locale, setLocale] = useState<Locale>("es")

  useEffect(() => {
    const fromURL = getLangFromURL()
    const saved = typeof window !== "undefined" ? (localStorage.getItem("locale") as Locale | null) : null
    const initial = fromURL || saved || "es"
    if (dicts[initial]) setLocale(initial)
    if (typeof document !== "undefined") document.documentElement.lang = initial
  }, [])

  useEffect(() => {
    if (typeof window !== "undefined") {
      localStorage.setItem("locale", locale)
      // Mantener <html lang="...">
      document.documentElement.lang = locale
    }
  }, [locale])

  const value = useMemo<I18nContextValue>(() => ({ locale, setLocale, t: dicts[locale] }), [locale])

  return <I18nContext.Provider value={value}>{children}</I18nContext.Provider>
}

export function useI18n() {
  const ctx = useContext(I18nContext)
  if (!ctx) throw new Error("useI18n must be used inside I18nProvider")
  return ctx
}
