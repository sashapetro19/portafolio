import PageShell from "@/components/page-shell"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useI18n } from "@/lib/i18n"
import SEOHead from "@/components/seo-head"

export default function ServicesPage() {
  const { t } = useI18n()
  return (
    <PageShell>
      <SEOHead title={`${t.services.title} · ${t.cv.name} ${t.cv.surname}`} description={"Servicios profesionales de UX/UI, front‑end y optimización."} />
      <h1 className="text-2xl font-bold">{t.services.title}</h1>
      <div className="mt-6 grid gap-4 sm:grid-cols-2">
        {t.services.items.map((s) => (
          <Card key={s.title} className="transition-transform duration-300 hover:-translate-y-0.5 hover:shadow-md">
            <CardHeader>
              <CardTitle className="text-lg">{s.title}</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-zinc-600 dark:text-zinc-400">{s.desc}</p>
            </CardContent>
          </Card>
        ))}
      </div>
    </PageShell>
  )
}
