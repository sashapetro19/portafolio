"use client"

import PageShell from "@/components/page-shell"
import ProjectCard from "@/components/project-card"
import { useEffect, useMemo, useState } from "react"
import { Input } from "@/components/ui/input"
import { useI18n } from "@/lib/i18n"
import { Button } from "@/components/ui/button"
import SEOHead from "@/components/seo-head"

type ProjectPayload = {
  slug: string
  image: string
  categories: string[]
  tools: string[]
  external?: string
  hero: string
  gallery: string[]
}

export default function PortfolioPage() {
  const { t } = useI18n()
  const [q, setQ] = useState("")
  const [active, setActive] = useState<string | "all">("all")
  const [data, setData] = useState<ProjectPayload[] | null>(null)

  useEffect(() => {
    async function load() {
      try {
        const r = await fetch("/api/projects", { cache: "no-store" })
        if (r.ok) {
          setData(await r.json())
          return
        }
        throw new Error("api not ok")
      } catch {
        try {
          const r2 = await fetch("/data/projects.json", { cache: "no-store" })
          setData(r2.ok ? await r2.json() : [])
        } catch {
          setData([])
        }
      }
    }
    load()
  }, [])

  const categories = useMemo(() => {
    const set = new Set<string>()
    ;(data || []).forEach((p) => p.categories.forEach((c) => set.add(c)))
    return ["all", ...Array.from(set)]
  }, [data])

  const filtered = useMemo(() => {
    const term = q.trim().toLowerCase()
    const list = t.cv.projects
    return list
      .filter((p) => {
        const meta = (data || []).find((m) => m.slug === p.slug)
        const matchCat = active === "all" || meta?.categories.includes(active)
        const matchText = !term || p.title.toLowerCase().includes(term) || p.description.toLowerCase().includes(term)
        return matchCat && matchText
      })
      .map((p) => {
        const meta = (data || []).find((m) => m.slug === p.slug)
        return {
          ...p,
          image: meta?.image || p.image,
          url: `/portfolio/${p.slug}`,
        }
      })
  }, [q, active, t, data])

  return (
    <PageShell>
      <SEOHead title={`${t.nav.portfolio} · ${t.cv.name} ${t.cv.surname}`} description={"Projects and case studies"} />
      <div className="mb-6 flex flex-col items-start justify-between gap-3 sm:flex-row sm:items-center">
        <h1 className="text-2xl font-bold">{t.nav.portfolio}</h1>
        <div className="w-full sm:w-80">
          <Input placeholder={t.cta.searchProjects} value={q} onChange={(e) => setQ(e.target.value)} />
        </div>
      </div>

      {categories.length > 1 ? (
        <div className="mb-4 flex flex-wrap gap-2">
          {categories.map((c) => (
            <Button key={c} size="sm" variant={active === c ? "default" : "outline"} onClick={() => setActive(c)}>
              {c}
            </Button>
          ))}
        </div>
      ) : null}

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {filtered.map((p) => (
          <div id={p.id} key={p.id}>
            <ProjectCard project={p} />
          </div>
        ))}
      </div>
      {filtered.length === 0 ? <p className="mt-6 text-zinc-600 dark:text-zinc-400">{t.cta.notFound}</p> : null}
    </PageShell>
  )
}
