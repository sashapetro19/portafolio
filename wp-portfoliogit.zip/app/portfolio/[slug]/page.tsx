"use client"

import PageShell from "@/components/page-shell"
import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { useI18n } from "@/lib/i18n"
import { useEffect, useMemo, useRef, useState } from "react"
import { useParams, useSearchParams } from "next/navigation"
import SEOHead from "@/components/seo-head"

type ProjectPayload = {
  slug: string
  image: string
  categories: string[]
  tools: string[]
  external?: string
  hero: string
  gallery: string[]
}

export default function ProjectDetail() {
  const { t } = useI18n()
  const params = useParams<{ slug: string }>()
  const search = useSearchParams()
  const [data, setData] = useState<ProjectPayload[] | null>(null)

  useEffect(() => {
    async function load() {
      try {
        const r = await fetch("/api/projects", { cache: "no-store" })
        if (r.ok) {
          setData(await r.json())
          return
        }
        throw new Error("api not ok")
      } catch {
        try {
          const r2 = await fetch("/data/projects.json", { cache: "no-store" })
          setData(r2.ok ? await r2.json() : [])
        } catch {
          setData([])
        }
      }
    }
    load()
  }, [])

  const meta = useMemo(() => (data || []).find((m) => m.slug === params.slug), [data, params.slug])
  const localized = useMemo(() => t.cv.projects.find((p) => p.slug === params.slug), [t, params.slug])

  const mode = search?.get("mode")
  const sectionsRef = useRef<Array<HTMLElement | null>>([])

  useEffect(() => {
    if (mode !== "presentation") return
    function onKey(e: KeyboardEvent) {
      const keys = new Set(["ArrowRight", "ArrowDown", "PageDown"])
      const back = new Set(["ArrowLeft", "ArrowUp", "PageUp"])
      const els = sectionsRef.current.filter(Boolean) as HTMLElement[]
      if (!els.length) return
      const currentIdx = els.findIndex((el) => {
        const rect = el.getBoundingClientRect()
        return rect.top >= 0 && rect.top < window.innerHeight * 0.6
      })
      if (keys.has(e.key)) {
        e.preventDefault()
        const next = els[Math.min(currentIdx + 1, els.length - 1)]
        next?.scrollIntoView({ behavior: "smooth", block: "start" })
      } else if (back.has(e.key)) {
        e.preventDefault()
        const prev = els[Math.max(currentIdx - 1, 0)]
        prev?.scrollIntoView({ behavior: "smooth", block: "start" })
      }
    }
    window.addEventListener("keydown", onKey)
    return () => window.removeEventListener("keydown", onKey)
  }, [mode])

  if (!localized) {
    return (
      <PageShell>
        <p className="text-zinc-600 dark:text-zinc-400">Not found.</p>
        <Link href="/portfolio" className="mt-4 inline-block">
          <Button variant="outline">{t.cta.back}</Button>
        </Link>
      </PageShell>
    )
  }

  return (
    <PageShell>
      <SEOHead title={`${localized.title} · ${t.sections.caseStudy}`} description={localized.description} />
      <article className="space-y-8">
        <header className="relative overflow-hidden rounded-xl border">
          <div className="absolute inset-0 -z-10 bg-[radial-gradient(ellipse_at_top_right,_rgba(16,185,129,.08),_transparent_60%)] dark:bg-[radial-gradient(ellipse_at_top_right,_rgba(16,185,129,.12),_transparent_60%)]" />
          <div className="grid gap-6 p-6 md:grid-cols-[1.3fr_1fr] md:p-10">
            <div>
              <h1 className="text-3xl font-bold">{localized.title}</h1>
              <p className="mt-2 text-zinc-600 dark:text-zinc-400">{localized.description}</p>
              <div className="mt-4 flex flex-wrap gap-2">
                {(meta?.categories || []).map((c) => (
                  <span key={c} className="rounded-full border border-zinc-200 px-3 py-1 text-sm dark:border-zinc-800">
                    {c}
                  </span>
                ))}
              </div>
              <div className="mt-4 flex gap-2">
                {meta?.external ? (
                  <a href={meta.external} target="_blank" rel="noopener noreferrer">
                    <Button>{t.cta.viewSite}</Button>
                  </a>
                ) : null}
                <Link href="/portfolio">
                  <Button variant="outline">{t.cta.back}</Button>
                </Link>
                <Link href={`/portfolio/${localized.slug}?mode=presentation`}>
                  <Button variant="secondary">Presentation</Button>
                </Link>
              </div>
            </div>
            <div className="relative aspect-[16/10] overflow-hidden rounded-lg border">
              <Image
                src={meta?.hero || localized.image}
                alt="Project hero"
                fill
                sizes="(min-width: 768px) 40vw, 100vw"
                className="object-cover"
                priority
              />
            </div>
          </div>
        </header>

        <section
          ref={(el) => (sectionsRef.current[0] = el as HTMLElement)}
          className="grid gap-6 md:grid-cols-[1.2fr_.8fr]"
        >
          <div className="space-y-4">
            <h2 className="text-xl font-semibold">{t.sections.caseStudy}</h2>
            <p className="text-zinc-700 dark:text-zinc-300">
              {/* Intro genérica si no hay WP: puedes alimentar desde CMS */}
              {"Exploración del problema, hipótesis y enfoque basado en UX."}
            </p>
            <h3 className="font-semibold">{"Challenge"}</h3>
            <p className="text-zinc-700 dark:text-zinc-300">
              {"Identificar fricciones en el flujo de usuario y en la comunicación del valor."}
            </p>
            <h3 className="font-semibold">{"Solution"}</h3>
            <p className="text-zinc-700 dark:text-zinc-300">
              {"Wireframes → prototipos → validación con usuarios → handoff a desarrollo."}
            </p>
            <h3 className="font-semibold">{"Results"}</h3>
            <p className="text-zinc-700 dark:text-zinc-300">
              {"Mejoras medibles en conversión, claridad y rendimiento."}
            </p>
          </div>
          <aside className="space-y-4 rounded-xl border p-4">
            <div>
              <h4 className="text-sm font-semibold uppercase tracking-wide text-zinc-500">{t.sections.tools}</h4>
              <ul className="mt-2 flex flex-wrap gap-2">
                {(meta?.tools || []).map((tool) => (
                  <li key={tool} className="rounded-full border px-3 py-1 text-sm dark:border-zinc-800">
                    {tool}
                  </li>
                ))}
              </ul>
            </div>
          </aside>
        </section>

        <section ref={(el) => (sectionsRef.current[1] = el as HTMLElement)}>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {(meta?.gallery || [localized.image]).map((g, i) => (
              <div
                key={g + i}
                className="relative aspect-[4/3] overflow-hidden rounded-lg border transition-transform duration-300 hover:-translate-y-0.5 hover:shadow-lg"
              >
                <Image
                  src={g || "/placeholder.svg"}
                  alt="Project gallery image"
                  fill
                  className="object-cover"
                  sizes="(min-width:1024px) 33vw, 50vw"
                />
              </div>
            ))}
          </div>
        </section>
      </article>
    </PageShell>
  )
}
