import PageShell from "@/components/page-shell"
import { useI18n } from "@/lib/i18n"
import Image from "next/image"
import SEOHead from "@/components/seo-head"

export default function AboutPage() {
  const { t } = useI18n()
  return (
    <PageShell>
      <SEOHead title={`${t.nav.about} · ${t.cv.name} ${t.cv.surname}`} description={t.cv.about} />
      <h1 className="text-2xl font-bold">{t.nav.about}</h1>
      <div className="mt-6 grid items-start gap-6 md:grid-cols-[2fr_1fr]">
        <div className="prose max-w-none">
          <p>{t.cv.about}</p>
          <h2 className="mt-6 text-xl font-semibold">{t.sections.courses}</h2>
          <ul className="mt-2 list-disc pl-5">
            {t.cv.courses.map((c) => (
              <li key={c.name}>
                <span className="font-medium">{c.name}</span>
                <span className="text-zinc-600 dark:text-zinc-400">{" — "}{c.dates}</span>
              </li>
            ))}
          </ul>
          <h2 className="mt-6 text-xl font-semibold">{t.sections.skills}</h2>
          <p className="mt-2">{t.cv.skills.join(" · ")}</p>
        </div>
        <div className="grid gap-4">
          <div className="relative aspect-[4/5] overflow-hidden rounded-lg border">
            <Image
              src="/photos/IMG-20231015-WA0021-1.jpg"
              alt="Creative portrait"
              fill
              sizes="(min-width:768px) 30vw, 90vw"
              className="object-cover"
              priority
            />
          </div>
          <div className="relative aspect-[16/10] overflow-hidden rounded-lg border">
            <Image
              src="/photos/IMG_1621.jpg"
              alt="Outdoor portrait"
              fill
              sizes="(min-width:768px) 30vw, 90vw"
              className="object-cover"
            />
          </div>
        </div>
      </div>
    </PageShell>
  )
}
