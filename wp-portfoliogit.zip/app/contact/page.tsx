import PageShell from "@/components/page-shell"
import ContactForm from "@/components/contact-form"
import ContactCards from "@/components/contact-cards"
import { useI18n } from "@/lib/i18n"
import SEOHead from "@/components/seo-head"

export default function ContactPage() {
  const { t } = useI18n()
  return (
    <PageShell>
      <SEOHead title={`${t.nav.contact} · ${t.cv.name} ${t.cv.surname}`} description={"Ponte en contacto para colaborar en proyectos UX/UI o front‑end."} />
      <h1 className="text-2xl font-bold">{t.nav.contact}</h1>
      <div className="mt-6 grid gap-6 md:grid-cols-2">
        <ContactCards />
        <ContactForm title={t.cta.writeMe} />
      </div>
    </PageShell>
  )
}
