import type { Metadata } from "next"
import { GeistSans } from "geist/font/sans"
import { GeistMono } from "geist/font/mono"
import "./globals.css"
import AppProviders from "@/components/app-providers"
import { AnalyticsMount } from "@/components/analytics"

export const metadata: Metadata = {
  title: "Portfolio",
  description: "UX/UI Portfolio",
  generator: "v0.dev",
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="es" suppressHydrationWarning>
      <head>
        <style>{`
html {
  font-family: ${GeistSans.style.fontFamily};
  --font-sans: ${GeistSans.variable};
  --font-mono: ${GeistMono.variable};
}
        `}</style>
      </head>
      <body>
        <AppProviders>
          {children}
          <AnalyticsMount />
        </AppProviders>
      </body>
    </html>
  )
}
