export async function POST(req: Request) {
  try {
    const body = await req.json()
    // En producción, reenvía a tu analítica real (PostHog, Umami, etc.)
    console.log("analytics", body)
    return new Response(JSON.stringify({ ok: true }), { status: 200 })
  } catch (e) {
    return new Response(JSON.stringify({ ok: false }), { status: 400 })
  }
}

export async function GET() {
  return new Response(JSON.stringify({ ok: true }), { status: 200 })
}
