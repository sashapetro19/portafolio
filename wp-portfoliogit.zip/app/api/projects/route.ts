import { projectsMeta } from "@/lib/projects-meta"

type Payload = {
  slug: string
  image: string
  categories: string[]
  tools: string[]
  external?: string
  hero: string
  gallery: string[]
}

export async function GET() {
  // Si defines NEXT_PUBLIC_WP_REST_URL/ WP_REST_URL, intenta leer de WP REST:
  const wp = process.env.WP_REST_URL || process.env.NEXT_PUBLIC_WP_REST_URL
  if (wp) {
    try {
      // Ejemplo genérico (ajusta campos a tu CPT 'project')
      const res = await fetch(`${wp.replace(/\/$/, "")}/wp-json/wp/v2/project?per_page=100&_embed`, {
        // @ts-ignore
        next: { revalidate: 60 },
      })
      if (res.ok) {
        const data = await res.json()
        // Mapea respuesta a nuestro formato mínimo
        const mapped: Payload[] = data.map((item: any) => ({
          slug: item.slug,
          image: item._embedded?.["wp:featuredmedia"]?.[0]?.source_url || "",
          categories: [],
          tools: [],
          external: item.meta?.project_url || "",
          hero: item._embedded?.["wp:featuredmedia"]?.[0]?.source_url || "",
          gallery: [],
        }))
        return Response.json(mapped)
      }
    } catch {}
  }

  // Fallback local (meta estático)
  const local: Payload[] = projectsMeta.map((m) => ({
    slug: m.slug,
    image: m.hero,
    categories: m.categories,
    tools: m.tools,
    external: m.external,
    hero: m.hero,
    gallery: m.gallery,
  }))
  return Response.json(local)
}
