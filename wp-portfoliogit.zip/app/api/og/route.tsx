import { ImageResponse } from "next/og"

// Route: /api/og?title=Your%20Title
export async function GET(req: Request) {
  const { searchParams } = new URL(req.url)
  const title = searchParams.get("title") || "Portfolio"

  return new ImageResponse(
    (
      <div
        style={{
          height: "100%",
          width: "100%",
          display: "flex",
          position: "relative",
          fontSize: 64,
          color: "#0b1324",
          background: "linear-gradient(135deg,#ecfeff,#f5f3ff)",
        }}
      >
        <div
          style={{
            position: "absolute",
            inset: 0,
            background:
              "radial-gradient(600px 300px at 0% 0%, rgba(16,185,129,.25), transparent), radial-gradient(600px 300px at 100% 100%, rgba(124,58,237,.25), transparent)",
          }}
        />
        <div style={{ display: "flex", flexDirection: "column", padding: 80, width: "100%" }}>
          <div style={{ fontSize: 28, color: "#334155" }}>Oleksandr · UX/UI</div>
          <div style={{ fontWeight: 800, lineHeight: 1.1, marginTop: 16 }}>{title}</div>
          <div style={{ marginTop: 24, fontSize: 28, color: "#475569" }}>oleksandr.design · Case Study</div>
        </div>
      </div>
    ),
    {
      width: 1200,
      height: 630,
    }
  )
}
