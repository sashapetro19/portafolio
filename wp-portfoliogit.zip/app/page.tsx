import PageShell from "@/components/page-shell"
import HeroInnovador from "@/components/hero-innovador"
import BadgeList from "@/components/badge-list"
import { Timeline } from "@/components/timeline"
import ProjectCard from "@/components/project-card"
import ContactCards from "@/components/contact-cards"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { useI18n } from "@/lib/i18n"
import PhotoShowcase from "@/components/photo-showcase"
import SEOHead from "@/components/seo-head"

export default function HomePage() {
  const { t } = useI18n()
  return (
    <PageShell>
      <SEOHead title={`${t.cv.name} ${t.cv.surname} · ${t.cv.role}`} description={"UX/UI, front‑end y sistemas — proyectos, experiencia y contacto."} />
      <HeroInnovador />

      <PhotoShowcase
        className="mt-10"
        photos={[
          { src: "/photos/IMG_1621.jpg", alt: "Outdoor portrait" },
          { src: "/photos/20241016_160233.jpg", alt: "City portrait" },
          { src: "/photos/IMG-20231015-WA0021-1.jpg", alt: "Creative portrait" },
        ]}
      />

      <section className="mt-10">
        <h2 className="text-xl font-semibold">{t.sections.skills}</h2>
        <BadgeList items={t.cv.skills} />
      </section>

      <section className="mt-10">
        <h2 className="text-xl font-semibold">{t.sections.courses}</h2>
        <div className="mt-4 grid gap-4 md:grid-cols-2">
          {t.cv.courses.map((c) => (
            <div key={c.name} className="rounded-lg border p-4 transition-transform duration-300 hover:-translate-y-0.5 hover:shadow-md">
              <h3 className="font-medium">{c.name}</h3>
              <p className="text-sm text-zinc-600 dark:text-zinc-400">{c.dates}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="mt-10">
        <Timeline title={t.sections.experience} items={t.cv.experience} />
      </section>

      <section className="mt-10">
        <Timeline title={t.sections.internship} items={t.cv.internship} />
      </section>

      <section className="mt-10">
        <h2 className="text-xl font-semibold">{t.sections.education}</h2>
        <div className="mt-4 space-y-4">
          {t.cv.education.map((ed) => (
            <div key={ed.degree + ed.org} className="rounded-lg border p-4 transition-transform duration-300 hover:-translate-y-0.5 hover:shadow-md">
              <div className="md:flex md:items-center md:justify-between">
                <div>
                  <h3 className="text-base font-semibold">
                    {ed.degree}
                    <span className="text-zinc-500">{" · "}{ed.org}</span>
                  </h3>
                  {ed.location ? <p className="text-sm text-zinc-600 dark:text-zinc-400">{ed.location}</p> : null}
                </div>
                <p className="mt-1 text-sm text-zinc-600 dark:text-zinc-400 md:mt-0">{ed.year}</p>
              </div>
              <ul className="mt-3 list-disc space-y-2 pl-5 text-sm text-zinc-700 dark:text-zinc-300">
                {ed.bullets.map((b) => <li key={b}>{b}</li>)}
              </ul>
            </div>
          ))}
        </div>
      </section>

      {t.cv.projects?.length ? (
        <section className="mt-10">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="text-xl font-semibold">{t.sections.portfolio}</h2>
            <Link href="/portfolio" className="text-sm text-zinc-700 underline underline-offset-4 dark:text-zinc-300">
              {t.cta.viewAll}
            </Link>
          </div>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {t.cv.projects.slice(0, 6).map((p) => (
              <ProjectCard key={p.id} project={{ ...p, url: `/portfolio/${p.slug}` }} />
            ))}
          </div>
        </section>
      ) : null}

      <section className="mt-10">
        <div className="mb-3 flex items-center justify-between">
          <h2 className="text-xl font-semibold">{t.sections.contactMore}</h2>
          <Link href="/contact">
            <Button variant="outline">{t.cta.writeMe}</Button>
          </Link>
        </div>
        <ContactCards />
      </section>
    </PageShell>
  )
}
