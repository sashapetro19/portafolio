## Summary

Describe the motivation and context.

## Changes
- [ ] Feature / fix 1
- [ ] Feature / fix 2

## Testing
How did you test it?

## Screenshots
If applicable.

## Checklist
- [ ] Typecheck passes (`npx tsc --noEmit`)
- [ ] Build passes (`npm run build`)
- [ ] Accessibility considered
- [ ] i18n strings updated if needed
