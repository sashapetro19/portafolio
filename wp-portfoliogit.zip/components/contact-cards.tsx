import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Mail, Phone, MapPin, Globe, CarFront } from 'lucide-react'
import { useI18n } from "@/lib/i18n"
import Reveal from "@/components/reveal"

export default function ContactCards() {
  const { t } = useI18n()
  return (
    <div className="grid gap-4 md:grid-cols-2">
      <Reveal>
        <Card className="transition-transform duration-300 hover:-translate-y-1 hover:shadow-lg">
          <CardHeader>
            <CardTitle className="text-lg">{t.contact.contact}</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 text-sm">
            <p className="flex items-center gap-2">
              <Mail className="h-4 w-4 text-emerald-700" />
              <a className="underline-offset-4 hover:underline" href={`mailto:${t.cv.contacts.email}`}>
                {t.cv.contacts.email}
              </a>
            </p>
            <p className="flex items-center gap-2">
              <Phone className="h-4 w-4 text-emerald-700" />
              <a className="underline-offset-4 hover:underline" href={`tel:${t.cv.contacts.phone.replace(/\s+/g, "")}`}>
                {t.cv.contacts.phone}
              </a>
            </p>
            {t.cv.contacts.addresses.map((a) => (
              <p key={a} className="flex items-center gap-2">
                <MapPin className="h-4 w-4 text-emerald-700" />
                {a}
              </p>
            ))}
            <p className="flex items-center gap-2">
              <CarFront className="h-4 w-4 text-emerald-700" />
              {t.contact.license}: <strong className="ml-1">{t.cv.drivingLicense}</strong>
            </p>
          </CardContent>
        </Card>
      </Reveal>

      <Reveal delay={100}>
        <Card className="transition-transform duration-300 hover:-translate-y-1 hover:shadow-lg">
          <CardHeader>
            <CardTitle className="text-lg">{t.contact.languages}</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 text-sm">
            {t.cv.languages.map((lng) => (
              <p key={lng} className="flex items-center gap-2">
                <Globe className="h-4 w-4 text-emerald-700" />
                {lng}
              </p>
            ))}
          </CardContent>
        </Card>
      </Reveal>
    </div>
  )
}
