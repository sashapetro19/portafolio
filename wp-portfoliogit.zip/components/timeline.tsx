import { type TimelineItem } from "@/lib/i18n"
import Reveal from "@/components/reveal"

export function Timeline({ items = [], title = "" }: { items?: TimelineItem[]; title?: string }) {
  return (
    <section>
      {title ? <h2 className="text-xl font-semibold">{title}</h2> : null}
      <ol className="mt-4 space-y-6">
        {items.map((it, idx) => (
          <Reveal key={idx}>
            <li className="relative rounded-lg border p-4 transition-transform duration-300 hover:-translate-y-0.5 hover:shadow-md">
              <div className="md:flex md:items-center md:justify-between">
                <div>
                  <h3 className="text-base font-semibold">
                    {it.title}
                    <span className="text-zinc-500">{" · "}{it.org}</span>
                  </h3>
                  {it.location ? <p className="text-sm text-zinc-600">{it.location}</p> : null}
                </div>
                <p className="mt-1 text-sm text-zinc-600 md:mt-0">
                  {it.start} {"–"} {it.end}
                </p>
              </div>
              <ul className="mt-3 list-disc space-y-2 pl-5 text-sm text-zinc-700">
                {it.bullets.map((b, i) => (
                  <li key={i}>{b}</li>
                ))}
              </ul>
            </li>
          </Reveal>
        ))}
      </ol>
    </section>
  )
}
