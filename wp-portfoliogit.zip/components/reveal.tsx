"use client"

import { useEffect, useRef, useState } from "react"

export default function Reveal({ children, delay = 0 }: { children?: React.ReactNode; delay?: number }) {
  const ref = useRef<HTMLDivElement>(null)
  const [show, setShow] = useState(false)

  useEffect(() => {
    const el = ref.current
    if (!el) return
    const obs = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) {
            setTimeout(() => setShow(true), delay)
            obs.unobserve(el)
          }
        })
      },
      { threshold: 0.1 }
    )
    obs.observe(el)
    return () => obs.disconnect()
  }, [delay])

  return (
    <div
      ref={ref}
      className={["transition-all duration-700 will-change-transform", show ? "translate-y-0 opacity-100" : "translate-y-4 opacity-0"].join(" ")}
    >
      {children}
    </div>
  )
}
