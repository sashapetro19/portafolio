export default function SkillsChips({
  items = ["HTML", "CSS", "JavaScript"],
}: {
  items?: string[]
}) {
  return (
    <ul className="flex flex-wrap gap-2" role="list">
      {items.map((s) => (
        <li
          key={s}
          className="rounded-full border border-zinc-200 bg-white px-3 py-1 text-sm"
        >
          {s}
        </li>
      ))}
    </ul>
  )
}
