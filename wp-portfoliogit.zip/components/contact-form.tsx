"use client"

import { useState } from "react"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Button } from "@/components/ui/button"
import { useToast } from "@/hooks/use-toast"

export default function ContactForm({
  title = "Envíame un mensaje",
  compact = false,
}: {
  title?: string
  compact?: boolean
}) {
  const { toast } = useToast()
  const [name, setName] = useState("")
  const [email, setEmail] = useState("")
  const [message, setMessage] = useState("")
  const [loading, setLoading] = useState(false)

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (!name || !email || !message) {
      toast({ title: "Campos incompletos", description: "Por favor, rellena todos los campos." })
      return
    }
    setLoading(true)
    // Prototype only
    await new Promise((r) => setTimeout(r, 600))
    setLoading(false)
    setName("")
    setEmail("")
    setMessage("")
    toast({
      title: "¡Enviado!",
      description: "Tu mensaje ha sido enviado en el prototipo.",
    })
  }

  return (
    <div className="w-full rounded-lg border bg-white p-4">
      <h3 className="mb-3 text-lg font-semibold">{title}</h3>
      <form className="grid gap-3" onSubmit={onSubmit}>
        <div className="grid gap-1">
          <label className="text-sm" htmlFor="name">
            {"Nombre"}
          </label>
          <Input
            id="name"
            placeholder="Tu nombre"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          />
        </div>
        <div className="grid gap-1">
          <label className="text-sm" htmlFor="email">
            {"Email"}
          </label>
          <Input
            id="email"
            type="email"
            placeholder="tucorreo@dominio.com"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>
        <div className="grid gap-1">
          <label className="text-sm" htmlFor="message">
            {"Mensaje"}
          </label>
          <Textarea
            id="message"
            placeholder="Cuéntame sobre tu proyecto…"
            rows={compact ? 4 : 6}
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            required
          />
        </div>
        <div className="pt-1">
          <Button type="submit" disabled={loading}>
            {loading ? "Enviando…" : "Enviar"}
          </Button>
        </div>
      </form>
    </div>
  )
}
