"use client"

import { useEffect } from "react"
import { useI18n, type Locale } from "@/lib/i18n"

function buildAltLinks(pathname: string): { hrefLang: string; href: string }[] {
  const langs: Locale[] = ["es", "en", "uk", "ru"]
  return langs.map((l) => ({
    hrefLang: l,
    href: `${window.location.origin}${pathname}?lang=${l}`,
  }))
}

export default function SEOHead({
  title,
  description,
}: {
  title: string
  description: string
}) {
  const { locale } = useI18n()

  useEffect(() => {
    if (typeof document === "undefined") return
    document.title = title

    const metaDesc = document.querySelector('meta[name="description"]')
    if (metaDesc) metaDesc.setAttribute("content", description)
    else {
      const m = document.createElement("meta")
      m.name = "description"
      m.content = description
      document.head.appendChild(m)
    }

    // hreflang alternates
    const old = Array.from(document.querySelectorAll('link[rel="alternate"][hreflang]'))
    old.forEach((el) => el.parentElement?.removeChild(el))
    const pathname = window.location.pathname
    const links = buildAltLinks(pathname)
    for (const l of links) {
      const link = document.createElement("link")
      link.rel = "alternate"
      link.setAttribute("hreflang", l.hrefLang)
      link.href = l.href
      document.head.appendChild(link)
    }

    // og:image dinamica
    const ogImg = document.querySelector('meta[property="og:image"]') as HTMLMetaElement | null
    const imgURL = `${window.location.origin}/api/og?title=${encodeURIComponent(title)}`
    if (ogImg) ogImg.setAttribute("content", imgURL)
    else {
      const m = document.createElement("meta")
      m.setAttribute("property", "og:image")
      m.setAttribute("content", imgURL)
      document.head.appendChild(m)
    }

    // og:title
    const ogTitle = document.querySelector('meta[property="og:title"]')
    if (ogTitle) ogTitle.setAttribute("content", title)
    else {
      const m = document.createElement("meta")
      m.setAttribute("property", "og:title")
      m.setAttribute("content", title)
      document.head.appendChild(m)
    }

    // language hint
    const metaLang = document.querySelector('meta[name="language"]') as HTMLMetaElement | null
    if (metaLang) metaLang.content = locale
    else {
      const m = document.createElement("meta")
      m.name = "language"
      m.content = locale
      document.head.appendChild(m)
    }
  }, [title, description, locale])

  return null
}
