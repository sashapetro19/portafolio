"use client"

import { I18nProvider } from "@/lib/i18n"
import { Toaster } from "@/components/ui/toaster"
import { ThemeProvider } from "@/components/theme-provider"
import PageTransition from "@/components/page-transition"

export default function AppProviders({ children }: { children?: React.ReactNode }) {
  return (
    <ThemeProvider attribute="class" defaultTheme="system" enableSystem disableTransitionOnChange>
      <I18nProvider>
        <PageTransition>{children}</PageTransition>
        <Toaster />
      </I18nProvider>
    </ThemeProvider>
  )
}
