import SiteHeader from "@/components/site-header"
import SiteFooter from "@/components/site-footer"

export default function PageShell({ children, className = "" }: { children?: React.ReactNode; className?: string }) {
  return (
    <div className="min-h-screen bg-white">
      <SiteHeader />
      <main className={["mx-auto w-full max-w-6xl px-4 py-8", className].join(" ")}>
        {children}
      </main>
      <SiteFooter />
    </div>
  )
}
