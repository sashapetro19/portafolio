"use client"

import Image from "next/image"
import { useRef } from "react"

type Photo = { src: string; alt: string }

export default function PhotoShowcase({
  photos = [
    { src: "/photos/IMG_1621.jpg", alt: "Outdoor portrait" },
    { src: "/photos/20241016_160233.jpg", alt: "City portrait" },
    { src: "/photos/IMG-20231015-WA0021-1.jpg", alt: "Creative portrait" },
  ],
  className = "",
}: {
  photos?: Photo[]
  className?: string
}) {
  const containerRef = useRef<HTMLDivElement>(null)

  function onMove(e: React.MouseEvent<HTMLDivElement>) {
    const el = containerRef.current
    if (!el) return
    const rect = el.getBoundingClientRect()
    const x = (e.clientX - rect.left) / rect.width - 0.5
    const y = (e.clientY - rect.top) / rect.height - 0.5
    el.style.setProperty("--rx", `${y * -6}deg`)
    el.style.setProperty("--ry", `${x * 6}deg`)
  }

  function onLeave() {
    const el = containerRef.current
    if (!el) return
    el.style.setProperty("--rx", "0deg")
    el.style.setProperty("--ry", "0deg")
  }

  return (
    <section className={["relative", className].join(" ")}>
      <div className="pointer-events-none absolute -top-10 left-1/2 h-56 w-56 -translate-x-1/2 rounded-full bg-emerald-400/20 blur-3xl dark:bg-emerald-600/20" />
      <div
        ref={containerRef}
        onMouseMove={onMove}
        onMouseLeave={onLeave}
        className="group relative mx-auto grid w-full max-w-6xl grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 [transform:perspective(1200px)_rotateX(var(--rx,0))_rotateY(var(--ry,0))] transition-transform duration-300"
      >
        {photos.map((p, i) => (
          <figure
            key={p.src + i}
            className={[
              "relative aspect-[4/5] overflow-hidden rounded-xl border bg-white shadow-sm dark:bg-zinc-950 dark:border-zinc-800",
              "transition-all duration-300 will-change-transform",
              "hover:shadow-xl hover:-translate-y-1",
              i % 3 === 0 ? "rotate-[-1.5deg]" : i % 3 === 1 ? "rotate-[1.2deg]" : "rotate-[0.4deg]",
            ].join(" ")}
          >
            <Image
              src={p.src || "/placeholder.svg?height=600&width=480&query=portrait"}
              alt={p.alt}
              fill
              sizes="(min-width:1024px) 30vw, (min-width:640px) 45vw, 100vw"
              className="object-cover grayscale transition duration-300 group-hover:grayscale-0"
              priority={i === 0}
            />
            <figcaption className="absolute bottom-2 left-2 rounded bg-white/70 px-2 py-1 text-xs text-zinc-700 backdrop-blur dark:bg-zinc-900/70 dark:text-zinc-300">
              {p.alt}
            </figcaption>
          </figure>
        ))}
      </div>
    </section>
  )
}
