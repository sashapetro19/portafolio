import Reveal from "@/components/reveal"

export default function BadgeList({ items = [], wrap = true }: { items?: string[]; wrap?: boolean }) {
  if (!items.length) return null
  return (
    <Reveal>
      <ul role="list" className={["mt-3 gap-2", wrap ? "flex flex-wrap" : "grid grid-cols-2"].join(" ")}>
        {items.map((it) => (
          <li key={it} className="rounded-full border border-zinc-200 bg-white px-3 py-1 text-sm transition-transform duration-300 hover:-translate-y-0.5 hover:shadow-sm">
            {it}
          </li>
        ))}
      </ul>
    </Reveal>
  )
}
