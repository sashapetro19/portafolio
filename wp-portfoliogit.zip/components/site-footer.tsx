import Link from "next/link"
import { useI18n } from "@/lib/i18n"

export default function SiteFooter() {
  const { t } = useI18n()
  return (
    <footer className="border-t bg-white">
      <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-4 px-4 py-6 sm:flex-row">
        <p className="text-sm text-zinc-600">
          {"© "} {new Date().getFullYear()} {t.cv.name} {t.cv.surname} {" · "} {t.cv.role}
        </p>
        <nav aria-label={"Footer"}>
          <ul className="flex items-center gap-2 text-sm">
            <li><Link className="rounded px-2 py-1 hover:bg-zinc-100" href="/about">{t.nav.about}</Link></li>
            <li><Link className="rounded px-2 py-1 hover:bg-zinc-100" href="/portfolio">{t.nav.portfolio}</Link></li>
            <li><Link className="rounded px-2 py-1 hover:bg-zinc-100" href="/services">{t.nav.services}</Link></li>
            <li><Link className="rounded px-2 py-1 hover:bg-zinc-100" href="/contact">{t.nav.contact}</Link></li>
          </ul>
        </nav>
      </div>
    </footer>
  )
}
