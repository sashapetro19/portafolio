"use client"

import { useI18n, type Locale } from "@/lib/i18n"
import { Button } from "@/components/ui/button"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Languages } from 'lucide-react'

const options: { code: Locale; label: string; emoji: string }[] = [
  { code: "es", label: "Español", emoji: "🇪🇸" },
  { code: "en", label: "English", emoji: "🇬🇧" },
  { code: "uk", label: "Українська", emoji: "🇺🇦" },
  { code: "ru", label: "Русский", emoji: "🇷🇺" },
]

export default function LanguageSwitcher() {
  const { locale, setLocale } = useI18n()
  const current = options.find((o) => o.code === locale) ?? options[0]

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" size="sm" aria-label="Language">
          <span className="mr-2">{current.emoji}</span>
          {current.label}
          <Languages className="ml-2 h-4 w-4" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        {options.map((o) => (
          <DropdownMenuItem key={o.code} onClick={() => setLocale(o.code)}>
            <span className="mr-2">{o.emoji}</span>
            {o.label}
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
