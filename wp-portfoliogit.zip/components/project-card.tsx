import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import Image from "next/image"
import Reveal from "@/components/reveal"
import { useI18n } from "@/lib/i18n"

export default function ProjectCard({
  project = { id: "0", title: "Proyecto", description: "Descripción corta del proyecto.", image: "/project-placeholder.png", url: "#" },
}: {
  project?: { id: string; title: string; description: string; image: string; url?: string }
}) {
  const { t } = useI18n()
  return (
    <Reveal>
      <Card className="h-full overflow-hidden transition-transform duration-300 hover:-translate-y-1 hover:shadow-xl">
        <div className="relative aspect-[16/9] w-full">
          <Image
            src={project.image || "/placeholder.svg?height=400&width=700&query=proyecto+portfolio"}
            alt={project.title}
            fill
            sizes="(min-width: 1024px) 33vw, (min-width: 640px) 50vw, 100vw"
            className="object-cover"
          />
        </div>
        <CardHeader className="pb-2">
          <CardTitle className="text-base">{project.title}</CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          <p className="text-sm text-zinc-600">{project.description}</p>
        </CardContent>
        <CardFooter className="gap-2">
          <Link href={`/portfolio#${project.id}`} className="w-full sm:w-auto">
            <Button variant="default" className="w-full">
              {t.cta.details}
            </Button>
          </Link>
          {project.url ? (
            <a href={project.url} target="_blank" rel="noopener noreferrer" className="w-full sm:w-auto">
              <Button variant="outline" className="w-full">
                {t.cta.viewSite}
              </Button>
            </a>
          ) : null}
        </CardFooter>
      </Card>
    </Reveal>
  )
}
