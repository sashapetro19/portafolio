"use client"

import { Button } from "@/components/ui/button"
import { Mail, Phone, MapPin, Linkedin } from 'lucide-react'
import { useI18n } from "@/lib/i18n"
import Reveal from "@/components/reveal"
import Image from "next/image"
import { useRef } from "react"
import { track } from "@/components/analytics"

export default function HeroInnovador() {
  const { t } = useI18n()
  const fullName = `${t.cv.name} ${t.cv.surname}`
  const ref = useRef<HTMLDivElement>(null)

  function onMove(e: React.MouseEvent<HTMLDivElement>) {
    const el = ref.current
    if (!el) return
    const r = el.getBoundingClientRect()
    const x = (e.clientX - r.left) / r.width - 0.5
    const y = (e.clientY - r.top) / r.height - 0.5
    el.style.setProperty("--rx", `${y * -4}deg`)
    el.style.setProperty("--ry", `${x * 4}deg`)
    el.style.setProperty("--tx", `${x * 6}px`)
    el.style.setProperty("--ty", `${y * 6}px`)
  }
  function onLeave() {
    const el = ref.current
    if (!el) return
    el.style.setProperty("--rx", "0deg")
    el.style.setProperty("--ry", "0deg")
    el.style.setProperty("--tx", "0px")
    el.style.setProperty("--ty", "0px")
  }

  return (
    <section className="relative overflow-hidden rounded-2xl border">
      <div className="absolute inset-0 -z-10">
        <div className="pointer-events-none absolute -left-24 -top-24 h-72 w-72 animate-pulse rounded-full bg-emerald-400/30 blur-3xl" />
        <div className="pointer-events-none absolute bottom-0 right-0 h-72 w-72 animate-pulse rounded-full bg-violet-400/30 blur-3xl" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_#ffffff_40%,_rgba(255,255,255,0)_60%)] dark:bg-[radial-gradient(ellipse_at_top_right,_#0b0b0b_40%,_rgba(0,0,0,0)_60%)]" />
      </div>

      <div className="relative grid gap-6 p-6 md:grid-cols-[1.5fr_1fr] md:p-10" ref={ref} onMouseMove={onMove} onMouseLeave={onLeave}>
        <Reveal>
          <div className="flex flex-col justify-center [transform:translate3d(var(--tx,0),var(--ty,0),0)] transition-transform duration-150">
            <span className="inline-flex items-center gap-2 text-sm font-medium text-emerald-700">
              <span className="inline-block h-2 w-2 rounded-full bg-emerald-600" />
              {t.hero.available}
            </span>
            <h1 className="mt-3 bg-gradient-to-r from-zinc-900 via-emerald-700 to-violet-700 bg-clip-text text-3xl font-extrabold tracking-tight text-transparent md:text-5xl dark:from-white dark:via-emerald-400 dark:to-violet-400">
              {fullName}
            </h1>
            <p className="mt-2 text-lg text-zinc-700 dark:text-zinc-300">{t.cv.role}</p>
            <p className="mt-3 max-w-2xl text-zinc-600 dark:text-zinc-400">{t.cv.about}</p>

            <div className="mt-6 flex flex-wrap items-center gap-2">
              <a href={`mailto:${t.cv.contacts.email}`} onClick={() => track("cta_click", { type: "email" })}>
                <Button>
                  <Mail className="mr-2 h-4 w-4" />
                  {t.hero.email}
                </Button>
              </a>
              <a href={`tel:${t.cv.contacts.phone.replace(/\s+/g, "")}`} onClick={() => track("cta_click", { type: "phone" })}>
                <Button variant="outline">
                  <Phone className="mr-2 h-4 w-4" />
                  {t.hero.call}
                </Button>
              </a>
              {t.cv.contacts.linkedin ? (
                <a href={t.cv.contacts.linkedin} target="_blank" rel="noopener noreferrer" onClick={() => track("cta_click", { type: "linkedin" })}>
                  <Button variant="secondary">
                    <Linkedin className="mr-2 h-4 w-4" />
                    {t.hero.linkedin}
                  </Button>
                </a>
              ) : null}
            </div>

            <div className="mt-4 flex flex-wrap items-center gap-3 text-sm text-zinc-700 dark:text-zinc-400">
              {t.cv.contacts.addresses.slice(0, 1).map((addr) => (
                <span key={addr} className="inline-flex items-center gap-2">
                  <MapPin className="h-4 w-4 text-emerald-700" />
                  {addr}
                </span>
              ))}
            </div>
          </div>
        </Reveal>

        <Reveal delay={100}>
          <div className="relative aspect-[4/5] w-full overflow-hidden rounded-xl border bg-white ring-1 ring-transparent transition-[transform,box-shadow] duration-300 hover:-translate-y-1 hover:shadow-xl [transform:perspective(1000px)_rotateX(var(--rx,0))_rotateY(var(--ry,0))] dark:bg-zinc-950">
            <Image
              src="/photos/20250217_080047-1.jpg"
              alt="Portrait"
              fill
              priority
              sizes="(min-width: 768px) 40vw, 90vw"
              className="object-cover"
            />
          </div>
        </Reveal>
      </div>
    </section>
  )
}
