"use client"

import { useEffect } from "react"
import { usePathname, useSearchParams } from "next/navigation"

export function track(event: string, props?: Record<string, any>) {
  try {
    fetch("/api/analytics", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ event, props, ts: Date.now() }),
    })
  } catch {}
}

export function AnalyticsMount() {
  const pathname = usePathname()
  const search = useSearchParams()
  useEffect(() => {
    track("pageview", { path: pathname, search: search?.toString() })
  }, [pathname, search])
  return null
}
