"use client"

import Link from "next/link"
import { useState } from "react"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { Menu } from 'lucide-react'
import { useI18n } from "@/lib/i18n"
import LanguageSwitcher from "@/components/language-switcher"
import ThemeToggle from "@/components/theme-toggle"

export default function SiteHeader() {
  const [open, setOpen] = useState(false)
  const { t } = useI18n()
  const brand = `${t.cv.name} ${t.cv.surname}`

  const links = [
    { href: "/", label: t.nav.home },
    { href: "/about", label: t.nav.about },
    { href: "/portfolio", label: t.nav.portfolio },
    { href: "/services", label: t.nav.services },
    { href: "/contact", label: t.nav.contact },
  ]

  return```typescriptreact file="components/site-header.tsx"
[v0-no-op-code-block-prefix]"use client"

import Link from "next/link"
import { useState } from "react"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { Menu } from 'lucide-react'
import { useI18n } from "@/lib/i18n"
import LanguageSwitcher from "@/components/language-switcher"
import ThemeToggle from "@/components/theme-toggle"

export default function SiteHeader() {
  const [open, setOpen] = useState(false)
  const { t } = useI18n()
  const brand = `${t.cv.name} ${t.cv.surname}`

  const links = [
    { href: "/", label: t.nav.home },
    { href: "/about", label: t.nav.about },
    { href: "/portfolio", label: t.nav.portfolio },
    { href: "/services", label: t.nav.services },
    { href: "/contact", label: t.nav.contact },
  ]

  return (
    <header className="sticky top-0 z-40 w-full border-b bg-white/80 backdrop-blur dark:bg-zinc-950/70">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4">
        <Link href="/" className="font-semibold text-zinc-900 dark:text-zinc-100">
          {brand}
        </Link>
        <nav className={cn("hidden items-center gap-3 md:flex")}>
          <ul className="flex items-center gap-2">
            {links.map((l) => (
              <li key={l.href}>
                <Link
                  className="rounded-md px-3 py-2 text-zinc-800 hover:bg-zinc-100 dark:text-zinc-100 dark:hover:bg-zinc-900"
                  href={l.href}
                >
                  {l.label}
                </Link>
              </li>
            ))}
          </ul>
          <LanguageSwitcher />
          <ThemeToggle />
        </nav>
        <div className="flex items-center gap-2 md:hidden">
          <LanguageSwitcher />
          <ThemeToggle />
          <Button
            variant="outline"
            size="icon"
            aria-haspopup="menu"
            aria-expanded={open ? "true" : "false"}
            onClick={() => setOpen((v) => !v)}
          >
            <Menu className="h-5 w-5" />
          </Button>
        </div>
      </div>
      <div className={cn("border-t md:hidden dark:border-zinc-800", open ? "block" : "hidden")}>
        <ul className="mx-auto flex max-w-6xl flex-col px-4 py-2">
          {links.map((l) => (
            <li key={l.href}>
              <Link
                className="block rounded-md px-3 py-2 hover:bg-zinc-100 dark:hover:bg-zinc-900"
                href={l.href}
                onClick={() => setOpen(false)}
              >
                {l.label}
              </Link>
            </li>
          ))}
        </ul>
      </div>
    </header>
  )
}
